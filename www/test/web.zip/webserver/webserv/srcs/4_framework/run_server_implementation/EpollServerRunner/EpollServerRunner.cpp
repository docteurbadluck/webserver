#include "EpollServerRunner.hpp"

EpollServerRunner::EpollServerRunner(const t_server_rules &server_rules, SessionHandlerUC &session_handler, RequestHandlerUC &request_handler) : server_rules(server_rules), session_handler(session_handler), request_handler(request_handler)
{
	this->epoll_fd = epoll_create(100);
	if (this->epoll_fd == -1)
		throw std::runtime_error("epoll_create failed");
	this->client_id = 1;
}

EpollServerRunner::~EpollServerRunner()
{
	close(this->epoll_fd);
}
