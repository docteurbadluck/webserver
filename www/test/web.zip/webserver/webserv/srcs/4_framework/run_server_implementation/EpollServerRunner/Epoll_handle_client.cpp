#include "EpollServerRunner.hpp"

void EpollServerRunner::handle_message_from_client(IClient *client)
{
    char buffer[1024];
    ssize_t count = recv(client->get_fd(), buffer, sizeof(buffer), 0);

    if (count <= 0)
    {
        disconnect_client(client);
        return ;
    }
    handle_received_data(client, buffer, count);
}

void EpollServerRunner::handle_received_data(IClient *client, const char *buffer, ssize_t count)
{
    std::string buf(buffer, count);
    client->appendToReadBuffer(buf);

    while (client->delimiter_found_in_readbuffer() == true)
    {
        std::string answer;
        t_parsed_request parsed_request;

        client->extract_header(); 
        this->request_handler.init_request_txt(client->get_request());
        parsed_request = this->request_handler.parse_header();
        if (parsed_request.methode == "GET" || parsed_request.body_lenght <= 0)
        {
            answer = this->request_handler.handle_the_request(server_rules, this->session_handler, "");
            send(client->get_fd(), answer.c_str(), answer.size(), MSG_NOSIGNAL);
            client->update_last_activity();
            client->flush_header();
        }
        else
        {
            if (client->getReadBuffer().size() <static_cast<long unsigned int> (parsed_request.body_lenght))
            {
                break;
            }
            client->flush_header();
            parsed_request.body = client->extract_body(parsed_request.body_lenght);
            answer = this->request_handler.handle_the_request(server_rules, this->session_handler, parsed_request.body);
            send(client->get_fd(), answer.c_str(), answer.size(), MSG_NOSIGNAL);
            client->flush_body(parsed_request.body_lenght);
            client->update_last_activity();
        }
    }
}

