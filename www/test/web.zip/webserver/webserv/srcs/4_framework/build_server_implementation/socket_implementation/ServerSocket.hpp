#pragma once
#include "ISocketServer.hpp"
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdexcept>
#include <cstdio>
#include <cstring>
#include <arpa/inet.h>
#include <string>


class ServerSocket : public ISocketServer {
public:
    ServerSocket();
    ~ServerSocket();
    void    bind_socket(unsigned long ip, int port);
    void    listen_socket(int backlog);
    int     get_fd() const;
	void    accept_connections();
private:
    int sockfd;
};