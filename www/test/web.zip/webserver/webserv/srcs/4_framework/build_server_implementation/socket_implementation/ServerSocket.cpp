#include "ServerSocket.hpp"
#include <iostream>

ServerSocket::ServerSocket() : sockfd(-1)
{
	this->sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (this->sockfd < 0)
		throw std::runtime_error("failed to create socket");
	
	int opt = 1;
	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
	{
		throw std::runtime_error("failed to set option");
	}

}

ServerSocket::~ServerSocket()
{
	if (this->sockfd >= 0)
		close(this->sockfd);
}

void ServerSocket::bind_socket(unsigned long ip, int port)
{
	struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));

    if (port <= 0 || port > 65535)
	{
        throw std::runtime_error("Invalid port");
	}
    if (ip == 0)
	{
        throw std::runtime_error("Invalid IP (INADDR_ANY not allowed)");
	}
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);

	unsigned char bytes[4];

	bytes[0] = (ip >>24) & 0xFF;
	bytes[1] = (ip >>16) & 0xFF;
	bytes[2] = (ip >>8) & 0xFF;
	bytes[3] = ip & 0xFF;

    char ip_str[16];
    snprintf(ip_str, sizeof(ip_str), "%u.%u.%u.%u", bytes[0], bytes[1], bytes[2], bytes[3]);

    if (inet_pton(AF_INET, ip_str, &addr.sin_addr) <= 0)
        throw std::runtime_error("Invalid IP address");

    if (bind(this->sockfd, (struct sockaddr*)&addr, sizeof(addr)) < 0)
	{
        throw std::runtime_error("Bind failed");
	}
	std::cout << "socket bind on : " << ip_str << "::" << port << std::endl;
}

void ServerSocket::listen_socket(int backlog)
{
    if (listen(this->sockfd, backlog) < 0)
        throw std::runtime_error("Listen failed");
}

int ServerSocket::get_fd() const
{
    return (this->sockfd);
}
