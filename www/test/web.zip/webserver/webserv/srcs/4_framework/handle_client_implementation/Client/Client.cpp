#include "Client.hpp"
#include <iostream>


Client::Client(int fd, int id_client) : fd(fd), id_client(id_client), delimiter("\r\n\r\n"), pos_delimiter(std::string::npos)
{
	    std::cout << "Client constructed: fd=" << fd << ", id=" << id_client << std::endl;
}

Client::~Client()
{

}

int Client::get_fd() const
{
	return fd;
}

void Client::readData()
{
	std::cout <<"readData called"<< std::endl;
}

void Client::writeData(std::string message)
{
	std::cout <<"writeData called"<< std::endl;

    send(this->get_fd(), message.c_str(), message.size(), MSG_NOSIGNAL);
}

bool Client::delimiter_found_in_readbuffer()
{
	this->pos_delimiter = this->read_buffer.find(this->delimiter);

	return (this->pos_delimiter != std::string::npos);
}

void Client::extract_request()
{
	this->request = this->read_buffer.substr(0, this->pos_delimiter);
	this->read_buffer.erase(0, this->pos_delimiter + this->delimiter.size());
}

std::string &Client::get_request()
{
	return (this->request);
}

void	Client::update_last_activity()
{
	this->last_activity = std::time(NULL);
}

bool	Client::is_timed_out(std::time_t now, int timeout)
{
	if (now > timeout + this->last_activity)
		return true;
	return false;
}

void 	Client::extract_header()
{
	this->request = this->read_buffer.substr(0, this->pos_delimiter);
}

void Client::flush_header()
{
	this->read_buffer.erase(0, this->pos_delimiter + this->delimiter.size());

}

std::string Client::extract_body(int body_lenght)
{
	std::string body;

	if(this->read_buffer.size() >= static_cast<long unsigned int>(body_lenght))
		body = this->read_buffer.substr(0, body_lenght );
	return body;
}

void Client::flush_body(int body_lenght)
{
	this->read_buffer.erase(0, body_lenght);
}
