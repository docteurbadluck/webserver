#include "Client.hpp"


void Client::appendToWriteBuffer(const std::string &data)
{
	this->read_buffer.append(data);
}
const std::string & Client::getWriteBuffer() const
{
	return this->write_buffer;
}

void Client::clearWriteBuffer()
{
	this->write_buffer.clear();
}
	