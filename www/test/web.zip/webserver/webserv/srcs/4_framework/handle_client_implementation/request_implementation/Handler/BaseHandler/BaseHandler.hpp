#pragma once
#include "parsed_request.hpp"
#include "SessionHandlerUC.hpp"
#include <map>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <sstream>
#include <fstream>
#include <iostream>
#include <dirent.h>
#include <sstream>
#include <iomanip>
#include <cstdio>
#include <unistd.h>

class BaseHandler
{
	public :
		BaseHandler();
		virtual ~BaseHandler();
  		virtual std::string handle(const t_parsed_request &req,
                               const t_server_rules &server_rules,
                               SessionHandlerUC &session_handler) = 0;

	protected :

		virtual void		verify_mandatory_field(const t_parsed_request &req) = 0;
    	virtual std::string build_http_response(int status_code, const std::string &body, const std::string &error_page_filepath, const std::string &filepath)= 0;
		virtual std::string build_directory_listing(const std::string &filepath, const std::string &url_path);
		virtual std::string interpret_html_body(const std::string body, SessionHandlerUC *session_handler);
		std::string 		add_default_file_if_directory(const std::string &path, const t_server_rules &server_rules);
		virtual std::string 		build_file_path(const std::string &path,
                                    const t_server_rules &server_rules);
    	virtual int 		check_file_status(const std::string &file_path, const t_server_rules &server_rules);
    	std::string read_file_content(const std::string &file_path);
		std::string verify_redirection(const std::string &path, const t_server_rules &server_rules);
		std::string map_to_url_path(const std::string &path,
        const std::pair<std::string, std::string> &file_system_root);
		std::string get_mime_type(const std::string &path, int status_code);
		void		init_field(const t_parsed_request &req, const t_server_rules &server_rules, SessionHandlerUC &session_handler);

		bool		directory_listing;
		bool		set_cookie_flag;
		t_parsed_request request;
		SessionHandlerUC *session_handler;
		t_server_rules	server_rules;
};