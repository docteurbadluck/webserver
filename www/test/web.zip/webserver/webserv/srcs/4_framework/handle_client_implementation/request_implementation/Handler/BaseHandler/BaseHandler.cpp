#include "BaseHandler.hpp"


BaseHandler::BaseHandler() {}

BaseHandler::~BaseHandler() {}

void    BaseHandler::init_field(const t_parsed_request &req, const t_server_rules &server_rules, SessionHandlerUC &session_handler)
{
    this->request = req;
    this->server_rules = server_rules;
    this->session_handler = &session_handler;
    this->directory_listing = false;
    this->set_cookie_flag = false;
}

std::string BaseHandler::verify_redirection(const std::string &path, const t_server_rules &server_rules)
{
    for (size_t i = 0; i < server_rules.redirection.size(); ++i)
    {
        if (path == server_rules.redirection[i].first)
        {
            std::ostringstream buffer;
            buffer << "HTTP/1.1 301 Moved Permanently\r\n";
            buffer << "Location: " << server_rules.redirection[i].second << "\r\n";
            buffer << "Content-Length: 0\r\n";
            buffer << "Connection: close\r\n\r\n"; //doit ont pour autant fermer la connection ? 
            return buffer.str();
        }
    }
    return ""; // pas de redirection
}

std::string BaseHandler::map_to_url_path(const std::string &path,
                            const std::pair<std::string, std::string> &file_system_root)
{
    const std::string &fs_root   = file_system_root.second;
    const std::string &url_root  = file_system_root.first;

    if (path.find(fs_root) == 0)
    {
        return url_root + path.substr(fs_root.size());
    }
    return path;
}

std::string BaseHandler::build_file_path(const std::string &path, const t_server_rules &server_rules)
{
    std::string file_path = server_rules.file_system_root.second;

    if (!file_path.empty() && file_path[file_path.size() - 1] != '/')
        file_path += '/';

    std::string relative_path = path;
    if (!server_rules.file_system_root.first.empty())
    {
        if (relative_path.find(server_rules.file_system_root.first) == 0)
        {
            relative_path = relative_path.substr(server_rules.file_system_root.first.size());
        }
        else
        {
            return ""; 
        }
    }
    if (!relative_path.empty() && relative_path[0] == '/')
        relative_path = relative_path.substr(1);  
    file_path += relative_path;
    struct stat st;
    if (stat(file_path.c_str(), &st) == 0 && S_ISDIR(st.st_mode) && file_path[file_path.size() - 1] != '/')
    {
        file_path += "/";
    }

    if (!file_path.empty() && file_path[file_path.size() - 1] == '/')
    {
        struct stat st;
        if (stat((file_path + server_rules.default_filepath).c_str(), &st) == 0)
            file_path += server_rules.default_filepath;
    }
    return file_path;
}

int BaseHandler::check_file_status(const std::string &file_path, const t_server_rules &server_rules)
{
    struct stat st;
    if (stat(file_path.c_str(), &st) != 0)
    {
        return 404;
    }
    if (!(st.st_mode & S_IRUSR))
    {
        return 403;
    }
    if (S_ISDIR(st.st_mode))
    {
        if (server_rules.enable_directory_listing == true)
            this->directory_listing = true;
        else
        {
            this->directory_listing = false;
            return  403;
        }
    }
    return 200;
}

std::string BaseHandler::read_file_content(const std::string &file_path)
{
    std::ifstream file(file_path.c_str(), std::ios::binary);
    if (!file.is_open())
        throw std::runtime_error("BaseHandler: File not found");

    std::ostringstream file_content_stream;
    file_content_stream << file.rdbuf();
    return file_content_stream.str();
}

std::string BaseHandler::get_mime_type(const std::string &path, int status_code)
{
    if (status_code != 200)
        return "text/html";
    size_t dot_pos = path.find_last_of(".");
    if (dot_pos == std::string::npos)
    {
        if (this->directory_listing == true)
            return "text/html";
        return "application/octet-stream"; // type par défaut (binaire)
    }
    std::string ext = path.substr(dot_pos + 1);
    if (ext == "html" || ext == "htm") return "text/html";
    if (ext == "css") return "text/css";
    if (ext == "js") return "application/javascript";
    if (ext == "json") return "application/json";
    if (ext == "jpg" || ext == "jpeg") return "image/jpeg";
    if (ext == "png") return "image/png";
    if (ext == "gif") return "image/gif";
    if (ext == "ico") return "image/x-icon";
    if (ext == "pdf") return "application/pdf";
    if (ext == "txt") return "text/plain";
    return "application/octet-stream";
}


std::string BaseHandler::interpret_html_body(const std::string body, SessionHandlerUC *session_handler)
{
    std::string result = body;
    size_t pos = result.find("@username");

    if (session_handler->is_valid_session(this->request.session_id) == false)
            return result;
    while (pos != std::string::npos)
    {
        result.replace(pos, 9, session_handler->get_session(this->request.session_id).username);
        pos = result.find("@username", pos + session_handler->get_session(this->request.session_id).username.size());
    }
    return result;
}



std::string BaseHandler::build_directory_listing(const std::string &filepath,
                                                const std::string &url_path)
{
    DIR *dir = opendir(filepath.c_str());
    if (!dir)
    {
        std::cerr << "ERROR: cannot open dir :" << filepath << "\n";
        return "";
    }
    std::ostringstream html;
    html << "<html><head><title>Index of " << url_path << "</title></head><body>";
    html << "<h1>Index of " << url_path << "</h1><ul>";
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL)
    {
        std::string name = entry->d_name;
        if (name == "." || name == "..")
            continue;

        html << "<li><a href=\"" << url_path;
        if (url_path[url_path.size()-1] != '/')
            html << "/";
        html << name << "\">" << name << "</a></li>";
    }
    html << "</ul></body></html>";
    closedir(dir);
    return html.str();
}
