#include "Client.hpp"

void Client::appendToReadBuffer(const std::string &data)
{
	this->read_buffer.append(data);
}
const std::string & Client::getReadBuffer() const
{
	return this->read_buffer;
}

void Client::clearReadBuffer()
{
	this->read_buffer.clear();
}
	