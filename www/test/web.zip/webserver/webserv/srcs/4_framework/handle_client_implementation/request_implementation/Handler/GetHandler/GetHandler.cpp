#include "GetHandler.hpp"


GetHandler::GetHandler()
{
}
GetHandler::~GetHandler() {}


std::string GetHandler::handle(const t_parsed_request &req, const t_server_rules &server_rules, SessionHandlerUC &session_handler) 
{
    //it miss CGI
    verify_mandatory_field(req);

    init_field(req, server_rules, session_handler);
    this->set_cookie_flag = this->request.were_cookies_sent;

    std::string url_path = map_to_url_path(req.path, server_rules.file_system_root);
    std::string redir_response = verify_redirection(url_path, server_rules);
    if (!redir_response.empty())
        return redir_response;
    std::string filepath = build_file_path(url_path, server_rules); 
    int status_code = check_file_status(filepath, server_rules);     

    if (status_code != 200)
        return build_http_response(status_code, "", server_rules.error_page_filepath, filepath);

    if (directory_listing == true)
    {
        return build_http_response(200, build_directory_listing(filepath, url_path), server_rules.error_page_filepath, filepath);
    }
    std::string body = read_file_content(filepath);
    return build_http_response(200, body, server_rules.error_page_filepath, filepath);
}

void GetHandler::verify_mandatory_field(const t_parsed_request &req)
{
    if (req.methode != "GET")
        throw std::runtime_error("GetHandler: Invalid method, expected GET");

    if (req.path.empty())
        throw std::runtime_error("GetHandler: Missing request target");
}


std::string GetHandler::interpret_html_body(const std::string body, SessionHandlerUC *session_handler)
{
    std::string result = body;
    size_t pos = result.find("@username");

    if (session_handler->is_valid_session(this->request.session_id) == false)
            return result;
    while (pos != std::string::npos)
    {
        result.replace(pos, 9, session_handler->get_session(this->request.session_id).username);
        pos = result.find("@username", pos + session_handler->get_session(this->request.session_id).username.size());
    }
    return result;
}

std::string GetHandler::build_http_response(int status_code, const std::string &body, const std::string &error_page_filepath, const std::string &filepath)
{
    std::ostringstream buffer;
    std::string response_body = interpret_html_body(body, this->session_handler);

    // Charger le fichier d'erreur si code != 200
    if (status_code != 200 && !error_page_filepath.empty())
    {
        std::ifstream file(error_page_filepath.c_str());
        if (file)
        {
            std::ostringstream file_content;
            file_content << file.rdbuf();
            response_body = file_content.str();
        }
    }
    // Status line
    if (status_code == 404)
    {
        buffer << "HTTP/1.1 404 Not Found\r\n";
    }
    else if (status_code == 403)
    {
        buffer << "HTTP/1.1 403 Forbidden\r\n";
    }
    else if (status_code == 500) 
    {
        buffer << "HTTP/1.1 500 Internal Server Error\r\n";
    } else
    {
        buffer << "HTTP/1.1 200 OK\r\n";
    }
    // Headers
    buffer << "Content-Length: " << response_body.size() << "\r\n";
    buffer << "Content-Type: "<< get_mime_type(filepath, status_code) << "\r\n";
    if (this->set_cookie_flag == false)
    {
        buffer << "Set-Cookie: session_id="<< this->session_handler->generate_session_id() <<"; Path=/\r\n";
    }
    buffer << "\r\n"; // fin headers
    std::cout <<buffer.str()<< std::endl;
    buffer << response_body;
    return buffer.str();
}


std::string GetHandler::build_directory_listing(const std::string &filepath,
                                                const std::string &url_path)
{
    DIR *dir = opendir(filepath.c_str());
    if (!dir)
    {
        std::cerr << "ERROR: cannot open dir :" << filepath << "\n";
        return "";
    }
    std::ostringstream html;
    html << "<html><head><title>Index of " << url_path << "</title></head><body>";
    html << "<h1>Index of " << url_path << "</h1><ul>";
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL)
    {
        std::string name = entry->d_name;
        if (name == "." || name == "..")
            continue;

        html << "<li><a href=\"" << url_path;
        if (url_path[url_path.size()-1] != '/')
            html << "/";
        html << name << "\">" << name << "</a></li>";
    }
    html << "</ul></body></html>";
    closedir(dir);
    return html.str();
}
