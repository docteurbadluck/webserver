#include "PostCloseHandler.hpp"

std::string PostCloseHandler::handle(const t_parsed_request &req, const t_server_rules &server_rules, SessionHandlerUC &session_handler)
{
    verify_mandatory_field(req);
    init_field(req, server_rules, session_handler);
    int status_code = set_status_code();
	return build_http_response(status_code, request.body, server_rules.error_page_filepath, "");
}

void PostCloseHandler::verify_mandatory_field(const t_parsed_request &req)
{
    if (req.methode != "POST")
        throw std::runtime_error("POST: Invalid method, expected POST");
}

int PostCloseHandler::set_status_code()
{
    return 200;
}

std::string PostCloseHandler::build_http_response(int status_code, const std::string &body, const std::string &error_page_filepath, const std::string &filepath)
{
	(void)body;
    (void)filepath;
    std::ostringstream buffer;
    std::string response_body;


    if (status_code != 200 && status_code != 204 && !error_page_filepath.empty())
    {
        std::ifstream file(error_page_filepath.c_str());
        if (file)
        {
            std::ostringstream file_content;
            file_content << file.rdbuf();
            response_body = file_content.str();
        }
    }
    else if (status_code == 403)
    {
        buffer << "HTTP/1.1 403 Forbidden\r\n";
    }
    else if (status_code == 500)
    {
        buffer << "HTTP/1.1 500 Internal Server Error\r\n";
    }
    else
    {
        buffer << "HTTP/1.1 200 OK\r\n";
        if (response_body.empty())
            response_body = "<html><body>close server command send</body></html>";
    }
    buffer << "Content-Length: " << response_body.size() << "\r\n";
    buffer << "Content-Type: " << "text/html" << "\r\n";
    buffer << "\r\n"; 
    if (status_code != 204)
        buffer << response_body;
    return buffer.str();
}

