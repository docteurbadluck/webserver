#include "RouterHandler.hpp"
#include "GetHandler.hpp"
#include "PostUploadHandler.hpp"
#include "PostLoginHandler.hpp"
#include "DeleteHandler.hpp"

RouterHandler::RouterHandler()
{
        handlers["GET"] = new GetHandler();
        handlers["DELETE"] = new DeleteHandler();
        handlers["POST"] = new PostUploadHandler();
        handlers["POSTUpload"] = new PostUploadHandler();
        handlers["PostLogin"] = new PostLoginHandler();

}
RouterHandler::~RouterHandler()
{
    delete handlers["GET"];
    delete handlers["DELETE"];
    delete handlers["POST"];
    delete handlers["POSTUpload"];
    delete handlers["PostLogin"];
}

std::string RouterHandler::handle(const t_parsed_request &req, const t_server_rules &server_rules, SessionHandlerUC &session_handler)
{
        std::map<std::string, BaseHandler*>::iterator it = handlers.find(req.methode);
        std::string result;
        if (it != handlers.end())
        {
                if (it->first == "POST")
                {
                        //result = it->second->handle(req, server_rules, session_handler);
                        //result = handlers["POSTUpload"]->handle(req, server_rules, session_handler);

                        
                        std::cout << req.path;
                        if (req.path.find("/upload") != std::string::npos)
                        {
                               result =  handlers["POSTUpload"]->handle(req, server_rules, session_handler);
                        }
                        else if (req.path.find("/login") != std::string::npos)
                        {
                                result =  handlers["PostLogin"]->handle(req, server_rules, session_handler);
                        }
                        else
                        {
                                return "HTTP/1.1 405 Method Not Allowed\r\n\r\n";
                        }
                }
                else
                {
                  result = it->second->handle(req, server_rules, session_handler);
                }
        }
        else
                return "HTTP/1.1 405 Method Not Allowed\r\n\r\n";
        return result;
}
    