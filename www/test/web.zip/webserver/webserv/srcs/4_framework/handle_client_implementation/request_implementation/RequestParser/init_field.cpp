#include "RequestParser.hpp"
#include <iostream>


void RequestParser::handle_host(const std::string &value)
{
    parsed_request.host = value;
}

void RequestParser::handle_content_length(const std::string &value)
{
    int length;
    std::stringstream ss(value);
    ss >> length;
    parsed_request.body_lenght = length;
}

void RequestParser::handle_content_type(const std::string &value)
{
    parsed_request.content_type = value;
}

void RequestParser::handle_connection(const std::string &value)
{
    std::string lower_value = value;
    std::transform(lower_value.begin(), lower_value.end(), lower_value.begin(), ::tolower);
    if (lower_value == "close")
        parsed_request.Connection = 1;
    else if (lower_value == "keep-alive")
        parsed_request.Connection = 0;
    else
        throw std::runtime_error("Invalid Connection header value");
}

void RequestParser::handle_cookie(const std::string &value)
{
    size_t start = 0;
    size_t end;
    while ((end = value.find(';', start)) != std::string::npos)
    {
        std::string cookie = value.substr(start, end - start);
        // enlever les espaces autour
        size_t first = cookie.find_first_not_of(" \t");
        size_t last = cookie.find_last_not_of(" \t");
        if (first != std::string::npos)
            cookie = cookie.substr(first, last - first + 1);
        parsed_request.cookies.push_back(cookie);
        start = end + 1;
    }
    if (start < value.size())
    {
        std::string cookie = value.substr(start);
        size_t first = cookie.find_first_not_of(" \t");
        size_t last = cookie.find_last_not_of(" \t");
        if (first != std::string::npos)
            cookie = cookie.substr(first, last - first + 1);
        parsed_request.cookies.push_back(cookie);
    }
}