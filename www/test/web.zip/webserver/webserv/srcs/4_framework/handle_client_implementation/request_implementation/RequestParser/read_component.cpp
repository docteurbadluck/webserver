#include "RequestParser.hpp"

void RequestParser::read_request_line()
{
	std::istringstream stream(this->request_txt);
    std::string			line;

    std::getline(stream, line);
	if (!line.empty() && line[line.size() - 1] == '\r')
	{
    	line.erase(line.size() - 1);
        std::istringstream first_line(line);
        first_line >> this->parsed_request.methode >> this->parsed_request.path;
        std::string version;
        first_line >> version;
        if (version == "HTTP/1.1")
			this->parsed_request.http_version = 1;
        else
			this->parsed_request.http_version = 0;
    }
	else
	{
		throw std::runtime_error("Invalid HTTP request: empty request line");
	}
}

void RequestParser::read_header_lines()
{
    std::istringstream stream(this->request_txt);
    std::string line;
    std::getline(stream, line);

	while(std::getline(stream, line))
	{
		if (!line.empty() && line[line.size() - 1] == '\r')
    		line.erase(line.size() - 1);
        if (line.empty())
            break;
		size_t pos = line.find(':');
        if (pos == std::string::npos)
            continue;
        std::string name = line.substr(0, pos);
        std::string value = line.substr(pos + 1);
		trim(name);
		trim(value);
        std::transform(name.begin(), name.end(), name.begin(), ::tolower);
        std::map<std::string, HeaderHandler>::iterator it = header_field_map.find(name);
        if (it != header_field_map.end())
            (this->*(it->second))(value);	
	}
}

void RequestParser::trim(std::string &s)
{
    s.erase(0, s.find_first_not_of(" \t\r\n"));
    s.erase(s.find_last_not_of(" \t\r\n") + 1);
}

void RequestParser::read_body()
{
    if (parsed_request.body_lenght > 0)
    {
        parsed_request.body = request_txt.substr(0, parsed_request.body_lenght);
    }
    else
        parsed_request.body.clear();
}