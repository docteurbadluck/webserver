#pragma once
#include <string>
#include "parsed_request.hpp"
#include "server_rules.hpp"
#include "SessionHandlerUC.hpp"

class IRequestHandler
{
	public :
	virtual std::string handle( const t_parsed_request &req,
								const t_server_rules& server_rules,
								SessionHandlerUC &session_handler) = 0;
	virtual ~IRequestHandler() {};
};