#include <string>
#include "server_rules.hpp"
#include "SessionHandlerUC.hpp"

class IRequestParser;
class IRequestHandler;

class RequestHandlerUC
{
	public :
		explicit	RequestHandlerUC(IRequestParser &request_parser, IRequestHandler &request_handler);
		~RequestHandlerUC();
		std::string			handle_the_request(const t_server_rules &server_rules, SessionHandlerUC &session_handler,const std::string &body);
		void				init_request_txt(const std::string &req);
		const t_parsed_request	&get_parsed_request();
		t_parsed_request		parse_header();
		void					read_body();

		private :
		IRequestParser		&parser;
    	IRequestHandler 	&handler;
};