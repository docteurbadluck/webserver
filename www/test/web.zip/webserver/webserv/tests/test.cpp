#include <iostream>

// les tests ne sont pas cencé couvrir toutes les fonctions mais plus les comportement
// les comportements globaux sur les api public.

int main()
{
    return 0;
}
